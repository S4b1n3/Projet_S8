#!/usr/bin/env bash

# Create the directory if needed.
mkdir -p /tmp/expe-out

# Clean the directory's content if any.
rm -rf /tmp/expe-out/*
