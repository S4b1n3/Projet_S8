.. _output_energy:

Energy
======

.. todo::
    Write documentation about energy-related output files.

    Maybe include some visualization tools there (Millian's scripts in evalys).
