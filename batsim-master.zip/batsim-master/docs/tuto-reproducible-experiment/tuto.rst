.. _tuto_reproducible_experiment:

Doing a reproducible experiment
===============================

.. todo::
    Write the "Doing a reproducible experiment" tutorial

    It would showcase (advanced) Nix usage.

    Why not reusing demo code here.
