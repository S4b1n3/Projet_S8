Batsim Developer Documentation
==============================

Welcome to Batsim's internal documentation !

These pages describe the different functions and types used by Batsim.<br/>
If you are more interested about how to use Batsim or how it works,
you should visit [our Github page](https://github.com/oar-team/batsim).

Additionally, you should give a look on
[Batsim's build status](https://travis-ci.org/oar-team/batsim) before choosing
a Batsim version to work with.<br/>
An automatically updated version of the present documentation can be found on
[this page](http://batsim.gforge.inria.fr).
